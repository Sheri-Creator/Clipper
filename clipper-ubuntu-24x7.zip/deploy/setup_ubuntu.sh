#!/usr/bin/env bash
set -e
source ~/clipper-app/venv/bin/activate
pip install --upgrade pip
pip install -r ~/clipper-app/src/requirements.txt
sudo cp ~/clipper-app/src/deploy/clipper.service /etc/systemd/system/clipper.service
sudo systemctl daemon-reload
sudo systemctl enable --now clipper
echo "Running at http://127.0.0.1:8765"
