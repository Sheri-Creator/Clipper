import json
import logging
import os
import re
import subprocess
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import httpx

logger = logging.getLogger("clipper.clipkaro_fx")

CAPTION_STYLES = {
    "bold": "FontSize=21,Bold=1,PrimaryColour=&H00FFFFFF,OutlineColour=&H00000000,BorderStyle=1,Outline=2,Alignment=2,MarginV=95",
    "box": "FontSize=19,Bold=1,PrimaryColour=&H00FFFFFF,BackColour=&H99000000,OutlineColour=&H00000000,BorderStyle=3,Outline=6,Shadow=0,Alignment=2,MarginV=95",
    "karaoke": "FontSize=22,Bold=1,PrimaryColour=&H0000E5FF,OutlineColour=&H00000000,BorderStyle=1,Outline=3,Alignment=2,MarginV=95",
    "minimal": "FontSize=17,Bold=0,PrimaryColour=&H00F5F5F4,OutlineColour=&H00000000,BorderStyle=1,Outline=1,Alignment=2,MarginV=85",
}


def _call_gemini_json(prompt: str, api_key: str, models: List[str], timeout: float = 18.0) -> Optional[Any]:
    if not api_key:
        return None
    payload = {"contents": [{"parts": [{"text": prompt}]}], "generationConfig": {"temperature": 0.2}}
    for model_name in models[:2]:
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{model_name}:generateContent?key={api_key}"
        try:
            with httpx.Client(timeout=timeout) as client:
                r = client.post(url, json=payload)
                if r.status_code == 200:
                    raw = r.json()["candidates"][0]["content"]["parts"][0]["text"].strip()
                    m = re.search(r"(\{.*\}|\[.*\])", raw, re.DOTALL)
                    if m:
                        return json.loads(m.group(0))
        except Exception as exc:
            logger.debug("Gemini JSON call skipped (%s): %s", model_name, exc)
    return None


def proofread_captions_with_gemini(
    segments: List[Dict[str, Any]],
    api_key: str,
    models: List[str],
    context_hint: str = "",
    roman_hinglish: bool = True,
    add_emojis: bool = True,
) -> List[Dict[str, Any]]:
    """Fixes Whisper mishearings, converts Hindi/Urdu to clean Roman Hinglish, and adds subtle emoji pops."""
    if not api_key or not segments or len(segments) > 45:
        return segments
    numbered = [{"i": idx, "t": s["text"]} for idx, s in enumerate(segments)]
    hinglish_rule = (
        "If any line is Hindi or Urdu, write it in natural Roman Hinglish/Urdu using English letters "
        '(e.g., "aaj hum GTA 6 khelenge"). '
        if roman_hinglish
        else ""
    )
    emoji_rule = (
        "Add 1 relevant emoji ONLY on strong hype/funny punchline words (max 1 in 4 lines). "
        if add_emojis
        else "Do not add emojis. "
    )
    prompt = (
        "Fix obvious speech-to-text mishearings and streamer/game names in these short video caption chunks. "
        f"{hinglish_rule}{emoji_rule}"
        'Keep each chunk 2-4 words and return ONLY JSON array [{"i": int, "t": "corrected text"}].\n'
        f"Context: {context_hint}\n"
        f"Captions: {json.dumps(numbered, ensure_ascii=False)}"
    )
    fixed = _call_gemini_json(prompt, api_key, models, timeout=14.0)
    if isinstance(fixed, list):
        by_idx = {int(item["i"]): str(item["t"]).strip() for item in fixed if "i" in item and "t" in item}
        out = []
        for idx, s in enumerate(segments):
            ns = dict(s)
            if idx in by_idx and by_idx[idx]:
                ns["text"] = by_idx[idx]
            out.append(ns)
        return out
    return segments


def find_deep_clips_with_gemini(
    all_segs: List[Dict[str, Any]],
    total_dur: float,
    max_clips: int,
    api_key: str,
    models: List[str],
    creator_name: str = "",
) -> List[Dict[str, Any]]:
    """
    ClipKaro-style Deep Storytelling finder:
    Finds both continuous moments AND multi-part deep clips (e.g. setup at 2:10 + payoff at 18:45).
    """
    if not api_key or not all_segs:
        return []
    transcript_lines = [f"[{s['start']:.1f}-{s['end']:.1f}] {s['text']}" for s in all_segs[:350]]
    prompt = (
        f"You are a viral Shorts editor analyzing a {int(total_dur)}s video by {creator_name}. "
        f"Pick up to {max_clips} standout Shorts (15-55s total each). You may either pick a continuous range "
        "OR join 2 related moments far apart (setup/question + payoff/answer) into one 'deep clip'.\n"
        "Return ONLY JSON array of objects:\n"
        '[{"title": "HOOK TITLE", "description": "1-2 sentence SEO summary", "hashtags": "#shorts #clips", '
        '"tags": ["tag1","tag2"], "score": int(0-100), "reason": "why it hooks", '
        '"parts": [[start_sec, end_sec], ...]}]\n\n'
        "Timestamped Transcript:\n" + "\n".join(transcript_lines)
    )
    res = _call_gemini_json(prompt, api_key, models, timeout=22.0)
    if not isinstance(res, list):
        return []
    out = []
    for item in res[:max_clips]:
        parts = []
        for p in item.get("parts", []):
            if isinstance(p, list) and len(p) == 2:
                s0, s1 = max(0.0, float(p[0])), min(total_dur, float(p[1]))
                if s1 - s0 >= 4.0:
                    parts.append((s0, s1))
        if parts:
            out.append(
                {
                    "parts": parts,
                    "title": str(item.get("title", "DEEP CLIP"))[:70],
                    "description": str(item.get("description", ""))[:300],
                    "hashtags": str(item.get("hashtags", "#shorts #clips")),
                    "tags": [str(t) for t in (item.get("tags") or ["shorts", "clips"])[:10]],
                    "score": int(item.get("score", 82)),
                    "reason": "[DeepClip] " + str(item.get("reason", "")),
                }
            )
    return out


def critic_review_clip(
    title: str,
    transcript_text: str,
    duration_sec: float,
    api_key: str,
    models: List[str],
) -> Dict[str, Any]:
    """
    Blind 2nd-opinion AI critic (ClipKaro-style): checks opening hook, ending payoff,
    and suggests trim offsets if the start/end drags.
    """
    if not api_key or not transcript_text.strip():
        return {"keep": True, "adjusted_score": None, "trim_start": 0.0, "note": ""}
    prompt = (
        "You are a strict blind YouTube Shorts critic. Judge whether this clip opens with a strong hook "
        "and lands on a clear payoff without dead air.\n"
        'Return ONLY JSON: {"keep": bool, "score": int(0-100), "trim_start_sec": float(0-6), "note": "short verdict"}\n'
        f"Duration: {duration_sec:.1f}s\nTitle: {title}\nTranscript: {transcript_text[:1200]}"
    )
    res = _call_gemini_json(prompt, api_key, models, timeout=12.0)
    if isinstance(res, dict):
        return {
            "keep": bool(res.get("keep", True)),
            "adjusted_score": int(res["score"]) if "score" in res else None,
            "trim_start": max(0.0, min(6.0, float(res.get("trim_start_sec", 0.0) or 0.0))),
            "note": str(res.get("note", "")),
        }
    return {"keep": True, "adjusted_score": None, "trim_start": 0.0, "note": ""}


def extract_multi_segment_clip(
    source_path: Path,
    parts: List[Tuple[float, float]],
    out_path: Path,
) -> bool:
    """Cuts 1 or more (start, end) segments and stitches them cleanly for Deep Clips."""
    if len(parts) == 1:
        s0, s1 = parts[0]
        res = subprocess.run(
            ["ffmpeg", "-y", "-ss", f"{s0:.2f}", "-i", str(source_path), "-t", f"{s1 - s0:.2f}", "-c", "copy", str(out_path)],
            capture_output=True,
            timeout=90,
        )
        return res.returncode == 0 and out_path.exists()

    part_files: List[Path] = []
    try:
        for idx, (s0, s1) in enumerate(parts):
            pf = out_path.with_name(f"{out_path.stem}_part{idx}.mp4")
            subprocess.run(
                [
                    "ffmpeg", "-y", "-ss", f"{s0:.2f}", "-i", str(source_path),
                    "-t", f"{s1 - s0:.2f}", "-c:v", "libx264", "-preset", "veryfast",
                    "-c:a", "aac", str(pf),
                ],
                capture_output=True,
                timeout=120,
            )
            if pf.exists():
                part_files.append(pf)
        if not part_files:
            return False
        list_f = out_path.with_suffix(".txt")
        list_f.write_text("\n".join(f"file '{p.resolve()}'" for p in part_files), encoding="utf-8")
        res = subprocess.run(
            ["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", str(list_f), "-c", "copy", str(out_path)],
            capture_output=True,
            timeout=90,
        )
        list_f.unlink(missing_ok=True)
        return res.returncode == 0 and out_path.exists()
    finally:
        for pf in part_files:
            pf.unlink(missing_ok=True)


def build_vertical_filter_complex(
    layout_mode: str = "zoom_9_16",
    cam_corner: str = "top_right",
    caption_style: str = "bold",
    srt_filename: Optional[str] = None,
    hook_title: str = "",
    punch_zoom: bool = True,
) -> str:
    """
    Builds FFmpeg filter_complex supporting:
    - zoom_9_16: 960px center-zoom gameplay over fast quarter-res blurred background
    - split_cam: Game (top 1080x1140) + Webcam crop (bottom 1080x780)
    Plus optional subtle rhythmic punch-zoom, 3.5s Hook Title banner, and styled SRT captions.
    """
    if layout_mode == "split_cam":
        cam_pos = {
            "top_right": "iw*0.72:0",
            "top_left": "0:0",
            "bottom_right": "iw*0.72:ih*0.66",
            "bottom_left": "0:ih*0.66",
        }.get(cam_corner, "iw*0.72:0")
        base_fc = (
            "split[game][cam];"
            "[game]scale=-2:1140,crop=1080:1140[top_game];"
            f"[cam]crop=iw*0.28:ih*0.34:{cam_pos},scale=1080:780:force_original_aspect_ratio=increase,crop=1080:780[bot_cam];"
            "[top_game][bot_cam]vstack=inputs=2"
        )
    else:
        base_fc = (
            "split[bg][fg];"
            "[bg]scale=270:480:force_original_aspect_ratio=increase,crop=270:480,boxblur=10:2,scale=1080:1920[bg_blur];"
            "[fg]scale=-2:960,crop=1080:960[fg_scaled];"
            "[bg_blur][fg_scaled]overlay=(W-w)/2:(H-h)/2"
        )

    post_filters = []
    if punch_zoom:
        # Subtle 4% periodic punch-zoom pulse every 6s (zero extra CPU)
        post_filters.append(
            "scale=w='if(lt(mod(t,6),0.35),1124,1080)':h='if(lt(mod(t,6),0.35),1998,1920)':eval=frame,"
            "crop=1080:1920"
        )

    if hook_title:
        safe_hook = "".join(c for c in hook_title.upper() if c.isalnum() or c in " -!?")[:34].strip()
        if safe_hook:
            font_path = ""
            if os.name == "nt" and Path("C:/Windows/Fonts/arialbd.ttf").exists():
                font_path = "fontfile='C\\:/Windows/Fonts/arialbd.ttf':"
            elif Path("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf").exists():
                font_path = "fontfile='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf':"
            if font_path:
                post_filters.append("drawbox=x=60:y=150:w=960:h=76:color=black@0.72:t=fill:enable='between(t,0,3.5)'")
                post_filters.append(
                    f"drawtext={font_path}text='{safe_hook}':fontcolor=white:fontsize=34:"
                    "x=(w-text_w)/2:y=172:enable='between(t,0,3.5)'"
                )

    if srt_filename:
        font_name = "Arial" if os.name == "nt" else "DejaVu Sans"
        style_str = CAPTION_STYLES.get(caption_style, CAPTION_STYLES["bold"])
        post_filters.append(f"subtitles='{srt_filename}':force_style='FontName={font_name},{style_str}'")

    if post_filters:
        base_fc += "," + ",".join(post_filters)
    return base_fc
