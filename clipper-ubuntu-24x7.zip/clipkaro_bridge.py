import logging
import os
import shutil
import subprocess
import sys
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List

logger = logging.getLogger("clipper.clipkaro_bridge")


def get_clipkaro_dir(app_root: Path) -> Path:
    env_dir = os.environ.get("CLIPKARO_DIR", "").strip()
    if env_dir:
        return Path(env_dir)
    # Place ClipKaro alongside ~/clipper-app or inside workspace
    home_ck = Path.home() / "ClipKaro"
    if home_ck.exists():
        return home_ck
    return app_root / "ClipKaro"


def clipkaro_status(app_root: Path) -> Dict[str, Any]:
    ck_dir = get_clipkaro_dir(app_root)
    return {
        "installed": (ck_dir / "run.py").exists(),
        "path": str(ck_dir),
        "git_ready": shutil.which("git") is not None,
    }


def install_clipkaro(app_root: Path) -> Dict[str, Any]:
    ck_dir = get_clipkaro_dir(app_root)
    if not (ck_dir / "run.py").exists():
        res = subprocess.run(
            ["git", "clone", "https://github.com/allthingsaman/ClipKaro.git", str(ck_dir)],
            capture_output=True,
            text=True,
            timeout=180,
        )
        if res.returncode != 0:
            raise RuntimeError(f"git clone failed: {res.stderr[:250]}")
    else:
        subprocess.run(["git", "-C", str(ck_dir), "pull"], capture_output=True, timeout=60)

    if (ck_dir / "install.py").exists():
        subprocess.run([sys.executable, str(ck_dir / "install.py")], cwd=str(ck_dir), timeout=600)
    return {"ok": True, "path": str(ck_dir)}


def run_clipkaro_job(
    app_root: Path,
    url_or_path: str,
    mode: str = "quick",
) -> List[Path]:
    """
    Runs ClipKaro's pipeline on a URL or local MP4 and returns newly created edited MP4 paths.
    """
    ck_dir = get_clipkaro_dir(app_root)
    if not (ck_dir / "run.py").exists():
        raise RuntimeError("ClipKaro is not installed yet. Click 'Install / Update ClipKaro' first.")

    out_root = ck_dir / "output"
    before = set(out_root.rglob("*.mp4")) if out_root.exists() else set()

    py_bin = ck_dir / ".venv" / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
    runner = str(py_bin) if py_bin.exists() else sys.executable

    cmd = [runner, str(ck_dir / "run.py"), url_or_path]
    if mode in ("quick", "standard", "deep"):
        cmd.extend(["--mode", mode])

    res = subprocess.run(cmd, cwd=str(ck_dir), capture_output=True, text=True, timeout=1800)
    if res.returncode != 0:
        raise RuntimeError(f"ClipKaro exited {res.returncode}: {(res.stderr or res.stdout)[-300:]}")

    after = set(out_root.rglob("*.mp4")) if out_root.exists() else set()
    new_files = sorted(p for p in (after - before) if "edited" in p.parts or p.parent.name == "edited")
    if not new_files:
        new_files = sorted(after - before)
    return new_files
